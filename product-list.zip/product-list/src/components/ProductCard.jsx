import React from 'react';

// ProductCard component to display individual product details
// Accepts a 'product' object as a prop
const ProductCard = ({ product }) => {

    // Handler for 'Add to Cart' button click
    const handleAddToCart = () => {
        // Requirements: Log product name to console
        console.log(`Add to Cart clicked for: ${product.name}`);
        // Optional: Visual feedback
        alert(`${product.name} added to cart!`);
    };

    return (
        <div className="product-card">
            <div className="product-image-container">
                {/* Product Image */}
                <img
                    src={product.image}
                    alt={product.name}
                    className="product-image"
                    loading="lazy"
                />
            </div>

            <div className="product-info">
                {/* Category */}
                <div className="product-category">{product.category}</div>

                {/* Name */}
                <h3 className="product-name">{product.name}</h3>

                {/* Rating Section */}
                <div className="product-rating">
                    {/* Display stars based on rating */}
                    {'★'.repeat(Math.round(product.rating))}
                    {'☆'.repeat(5 - Math.round(product.rating))}
                    <span style={{ marginLeft: '5px', color: '#94a3b8' }}>({product.rating})</span>
                </div>

                <div className="product-footer">
                    {/* Price */}
                    <span className="product-price">₹{product.price.toFixed(2)}</span>

                    {/* Add to Cart Button */}
                    <button className="add-btn" onClick={handleAddToCart}>
                        Add to Cart
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ProductCard;
