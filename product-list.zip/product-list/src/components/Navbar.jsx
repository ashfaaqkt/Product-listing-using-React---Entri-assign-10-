import React from 'react';

// Simple Navigation Bar component
const Navbar = () => {
    return (
        <nav className="navbar">
            {/* Logo/Brand Name */}
            <div className="logo">Entri Product Hub</div>

            {/* Navigation Links */}
            <div className="nav-links">
                <a href="#" className="nav-link">Home</a>
                <a href="#" className="nav-link">Shop</a>
                <a href="#" className="nav-link">About</a>
                <a href="#" className="nav-link">Cart</a>
            </div>
        </nav>
    );
};

export default Navbar;
