import React from 'react';

// Footer component to display credits and copyright
const Footer = () => {
    return (
        <footer className="footer">
            <p>&copy; {new Date().getFullYear()} Ashfaaq KT.</p>
            {/* Credits as requested by the user */}
            <p>Developed by <strong>Ashfaaq Feroz Muhammad</strong></p>
            <p>Entri Assignment (10)</p>
        </footer>
    );
};

export default Footer;
