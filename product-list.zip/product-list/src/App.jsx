import React, { useState } from 'react';
// Importing components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
// Importing data
import { products as initialProducts } from './data';

// Main App Component
const App = () => {
  // State 1: Search Term (stores what the user Types)
  const [searchTerm, setSearchTerm] = useState('');

  // State 2: Selected Category (stores the chosen category filter)
  const [selectedCategory, setSelectedCategory] = useState('All');

  // State 3: Sort Option (stores the current sorting method)
  const [sortOption, setSortOption] = useState('default');

  // --- Helper Logic ---

  // Get unique categories for the dropdown
  // We map over products to get categories, then use Set to remove duplicates
  const categories = ['All', ...new Set(initialProducts.map(product => product.category))];

  // --- Filtering & Sorting Logic ---

  // 1. Filter by Category
  let filteredProducts = initialProducts;
  if (selectedCategory !== 'All') {
    filteredProducts = filteredProducts.filter(product => product.category === selectedCategory);
  }

  // 2. Filter by Search Term (Name)
  // We convert both to lowercase to make the search case-insensitive
  if (searchTerm) {
    filteredProducts = filteredProducts.filter(product =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  // 3. Sort Results
  // We create a copy of the array using [...] before sorting to avoid mutating the filtered list directly
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortOption === 'price-low') {
      return a.price - b.price; // Low to High
    } else if (sortOption === 'price-high') {
      return b.price - a.price; // High to Low
    } else if (sortOption === 'rating') {
      return b.rating - a.rating; // Highest Rating first
    }
    return 0; // Default order
  });

  return (
    <div className="app-container">
      {/* 1. Header Section */}
      <Navbar />

      <main className="main-content">
        <div className="products-header">
          <h1 className="products-title">Our Products</h1>
          <p>Explore our premium collection of items.</p>
        </div>

        {/* 2. Controls Section (Search, Filter, Sort) */}
        <section className="controls-bar">
          {/* Search Input */}
          <input
            type="text"
            placeholder="Search products..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />

          {/* Category Dropdown */}
          <select
            className="filter-select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>

          {/* Sort Dropdown */}
          <select
            className="sort-select"
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
          >
            <option value="default">Sort By</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Rating: High to Low</option>
          </select>
        </section>

        {/* 3. Product Grid Display */}
        <div className="product-grid">
          {sortedProducts.length > 0 ? (
            sortedProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))
          ) : (
            <div style={{ color: 'white', textAlign: 'center', width: '100%', gridColumn: '1/-1' }}>
              <h3>No products found matching your criteria.</h3>
            </div>
          )}
        </div>
      </main>

      {/* 4. Footer Section */}
      <Footer />
    </div>
  );
};

export default App;
